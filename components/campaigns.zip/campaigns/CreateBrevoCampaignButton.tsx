
"use client";

import { useState } from "react";

type Props = {
  campaignId: string;
};

export function CreateBrevoCampaignButton({ campaignId }: Props) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [success, setSuccess] = useState(false);

  async function handleCreate() {
    setLoading(true);
    setResult("");
    setSuccess(false);

    try {
      const response = await fetch(
        `/api/campaigns/${campaignId}/create-brevo`,
        { method: "POST" }
      );

      const data = await response.json();

      if (!response.ok) {
        setResult(data.error || "Unable to create Brevo campaign.");
        return;
      }

      setSuccess(true);
      setResult(
        `Brevo draft created successfully! Campaign ID: ${data.brevoCampaignId}`
      );
    } catch {
      setResult("Unable to connect to the campaign creation API.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-3">
      <button
        type="button"
        onClick={handleCreate}
        disabled={loading || success}
        className="rounded-lg bg-orange-500 px-6 py-3 font-semibold text-white transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-60"
      >
        {loading
          ? "Creating Brevo Draft..."
          : success
            ? "Brevo Draft Created"
            : "Create Email Draft in Brevo"}
      </button>

      {result && (
        <p
          className={`rounded-lg p-3 text-sm ${
            success
              ? "bg-green-500/10 text-green-400"
              : "bg-red-500/10 text-red-400"
          }`}
        >
          {result}
        </p>
      )}
    </div>
  );
}
