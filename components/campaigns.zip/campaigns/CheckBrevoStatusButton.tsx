
"use client";

import { useState } from "react";

type Props = {
  campaignId: string;
};

export function CheckBrevoStatusButton({ campaignId }: Props) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [status, setStatus] = useState("");

  async function handleCheck() {
    setLoading(true);
    setResult("");

    try {
      const response = await fetch(
        `/api/campaigns/${campaignId}/check-brevo`,
        { method: "POST" }
      );

      const data = await response.json();

      if (!response.ok) {
        setResult(data.error || "Unable to check campaign status.");
        return;
      }

      setStatus(data.campaignStatus);
      setResult(
        `Brevo status: ${data.brevoStatus}. EmailBlast status: ${data.campaignStatus}.`
      );
    } catch {
      setResult("Unable to connect to the status-check API.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-3">
      <button
        type="button"
        onClick={handleCheck}
        disabled={loading}
        className="rounded-lg border border-orange-500 px-5 py-3 font-semibold text-orange-400 transition hover:bg-orange-500/10 disabled:opacity-60"
      >
        {loading ? "Checking..." : "Check Sending Status"}
      </button>

      {result && (
        <p className="rounded-lg bg-white/5 p-3 text-sm text-gray-300">
          {result}
        </p>
      )}
    </div>
  );
}
