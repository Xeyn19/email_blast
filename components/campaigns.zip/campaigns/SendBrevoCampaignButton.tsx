
"use client";

import { useState } from "react";

type Props = {
  campaignId: string;
};

export function SendBrevoCampaignButton({ campaignId }: Props) {
  const [confirming, setConfirming] = useState(false);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState("");
  const [success, setSuccess] = useState(false);

  async function handleSend() {
    setLoading(true);
    setResult("");
    setSuccess(false);

    try {
      const response = await fetch(
        `/api/campaigns/${campaignId}/send-brevo`,
        { method: "POST" }
      );

      const data = await response.json();

      if (!response.ok) {
        setResult(
          data.error || "Unable to send the campaign."
        );
        return;
      }

      setSuccess(true);
      setConfirming(false);
      setResult(
        "Brevo accepted your campaign for processing. Campaign status: Sending."
      );
    } catch {
      setResult(
        "Unable to connect to the campaign sending API. Check your campaign status before trying again."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-3">
      {!confirming ? (
        <button
          type="button"
          onClick={() => setConfirming(true)}
          disabled={loading || success}
          className="rounded-lg bg-orange-500 px-6 py-3 font-semibold text-white transition hover:bg-orange-600 disabled:cursor-not-allowed disabled:opacity-60"
        >
          Send Campaign
        </button>
      ) : (
        <div className="space-y-3 rounded-xl border border-orange-500/40 bg-orange-500/5 p-4">
          <h3 className="font-semibold text-white">
            Confirm Campaign Sending
          </h3>

          <p className="text-sm text-gray-300">
            You are about to send this email campaign
            to its selected recipients through Brevo.
            This action cannot be undone.
          </p>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              onClick={handleSend}
              disabled={loading}
              className="rounded-lg bg-orange-500 px-5 py-2.5 font-semibold text-white hover:bg-orange-600 disabled:opacity-60"
            >
              {loading ? "Sending..." : "Yes, Send Campaign"}
            </button>

            <button
              type="button"
              onClick={() => setConfirming(false)}
              disabled={loading}
              className="rounded-lg border border-gray-600 px-5 py-2.5 text-gray-300 hover:bg-white/5 disabled:opacity-60"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {result && (
        <p
          className={`rounded-lg p-3 text-sm ${
            success
              ? "bg-green-500/10 text-green-400"
              : "bg-red-500/10 text-red-400"
          }`}
        >
          {result}
        </p>
      )}
    </div>
  );
}
