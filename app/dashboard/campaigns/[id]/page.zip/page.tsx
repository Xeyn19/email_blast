import { SyncBrevoButton } from "@/components/campaigns/SyncBrevoButton";
import { CreateBrevoCampaignButton } from "@/components/campaigns/CreateBrevoCampaignButton";
import { SendBrevoCampaignButton } from "@/components/campaigns/SendBrevoCampaignButton";
import { CheckBrevoStatusButton } from "@/components/campaigns/CheckBrevoStatusButton";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { connection } from "next/server";
import { Suspense } from "react";
import { createClient } from "@/lib/supabase/server";

type PageProps = {
  params: Promise<{ id: string }>;
};

export default function CampaignDetailsPage({ params }: PageProps) {
  return (
    <Suspense fallback={<div className="p-8">Loading campaign...</div>}>
      <CampaignDetailsContent params={params} />
    </Suspense>
  );
}

async function CampaignDetailsContent({ params }: PageProps) {
  await connection();

  const { id } = await params;
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/");

  const { data: campaign, error } = await supabase
    .from("campaigns")
    .select("*")
    .eq("id", id)
    .single();

  if (error || !campaign) notFound();

  const recipientIds = campaign.recipient_contact_ids ?? [];

  let recipients: {
    id: string;
    full_name: string | null;
    email: string;
    status: string;
  }[] = [];

  if (recipientIds.length > 0) {
    const { data } = await supabase
      .from("contacts")
      .select("id, full_name, email, status")
      .in("id", recipientIds);

    recipients = data ?? [];
  }

  return (
    <main className="min-h-screen bg-[#f8f8f8] p-6 md:p-10">
      <div className="mx-auto max-w-5xl space-y-8">

        <div>
          <Link
            href="/dashboard/campaigns"
            className="text-sm font-medium text-orange-600 hover:underline"
          >
            ← Back to Campaigns
          </Link>

          <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {campaign.name}
              </h1>
              <p className="mt-2 text-sm text-gray-500">
                Campaign details and recipients
              </p>
            </div>

           <div className="flex flex-wrap items-center gap-3">
  {campaign.status === "draft" && (
    <Link
      href={`/dashboard/campaigns/${campaign.id}/edit`}
      className="rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600"
    >
      Edit Draft
    </Link>
  )}

  <span className="rounded-full bg-orange-100 px-4 py-2 text-sm font-semibold capitalize text-orange-700">
    {campaign.status}
  </span>
</div>
          </div>
        </div>

        <section className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-5 text-lg font-bold text-gray-900">
            Campaign Information
          </h2>

          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-500">Campaign Name</p>
              <p className="font-medium text-gray-900">{campaign.name}</p>
            </div>

            <div>
              <p className="text-sm text-gray-500">Email Subject</p>
              <p className="font-medium text-gray-900">
                {campaign.subject || "No subject"}
              </p>
            </div>

            <div>
              <p className="text-sm text-gray-500">Preview Text</p>
              <p className="font-medium text-gray-900">
                {campaign.preview_text || "No preview text"}
              </p>
            </div>

            <div>
              <p className="text-sm text-gray-500">Created</p>
              <p className="font-medium text-gray-900">
                {new Date(campaign.created_at).toLocaleString()}
              </p>
            </div>
          </div>
        </section>

        <section className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-2 text-lg font-bold text-gray-900">
            Selected Recipients
          </h2>

          <p className="mb-5 text-sm text-gray-500">
            {recipientIds.length} selected contact(s)
          </p>

          {recipients.length === 0 ? (
            <p className="text-sm text-gray-500">
              No recipients were found for this campaign.
            </p>
          ) : (
            <div className="divide-y divide-gray-100">
              {recipients.map((contact) => (
                <div
                  key={contact.id}
                  className="flex flex-wrap items-center justify-between gap-3 py-3"
                >
                  <div>
                    <p className="font-medium text-gray-900">
                      {contact.full_name || "Unnamed Contact"}
                    </p>
                    <p className="text-sm text-gray-500">
                      {contact.email}
                    </p>
                  </div>

                  <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-medium capitalize text-gray-600">
                    {contact.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </section>

        <section className="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
          <h2 className="mb-4 text-lg font-bold text-gray-900">
            Email Content
          </h2>

          <iframe
            title="Campaign email preview"
            sandbox=""
            srcDoc={campaign.html_content || "<p>No email content.</p>"}
            className="min-h-[350px] w-full rounded-lg border border-gray-200 bg-white"
          />
        </section>

   <div className="flex justify-end">
  <SyncBrevoButton campaignId={campaign.id} />
  <CreateBrevoCampaignButton campaignId={campaign.id} />
  {campaign.brevo_campaign_id && campaign.status === "draft" && (
  <SendBrevoCampaignButton campaignId={campaign.id} />
)}
{campaign.brevo_campaign_id && (
  <CheckBrevoStatusButton campaignId={campaign.id} />
)}
</div>

      </div>
    </main>
  );
}
